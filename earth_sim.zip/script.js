// عناصر DOM
const playPauseBtn = document.getElementById('playPause');
const stepBackBtn = document.getElementById('stepBack');
const stepFwdBtn = document.getElementById('stepFwd');
const langToggleBtn = document.getElementById('langToggle');
const speedSlider = document.getElementById('speed');
const speedVal = document.getElementById('speedVal');
const scrub = document.getElementById('scrub');
const yearLabel = document.getElementById('year');
const eventsDiv = document.getElementById('events');
const descDiv = document.getElementById('desc');
const scenarioSelect = document.getElementById('scenarioSelect');

// متغيرات المحاكاة
let running = false;
let year = 0;
let speed = parseInt(speedSlider.value);
let scenario = 'sustainable';

// بيانات مراحل (مبسطة)
const phases = [
  {year:0, text:'🌍 تكوين الأرض'},
  {year:100, text:'🌊 ظهور المياه'},
  {year:200, text:'🦠 الحياة البدائية'},
  {year:400, text:'🐟 ظهور الكائنات متعددة الخلايا'},
  {year:600, text:'🦖 عصر الديناصورات'},
  {year:700, text:'🐒 ظهور الثدييات'},
  {year:900, text:'👤 ظهور الإنسان'},
  {year:1000, text:'🚀 المستقبل (حسب السيناريو)'}
];

// تحديث العرض
function updateUI(){
  scrub.value = year;
  yearLabel.textContent = year + ' م.س';
  speedVal.textContent = 'x' + speed;
  // وصف المرحلة
  let phase = phases.findLast(p=>p.year<=year);
  if(phase){
    descDiv.textContent = phase.text;
  }
}

// تحديث الأحداث
function renderEvents(){
  eventsDiv.innerHTML = phases.map(p=>`<div>${p.year} : ${p.text}</div>`).join('');
}

// حلقة المحاكاة
function tick(){
  if(running){
    year += Math.floor(speed/10);
    if(year>1000) year=1000;
    updateUI();
  }
  requestAnimationFrame(tick);
}

// تحكم
playPauseBtn.onclick=()=>{running=!running;playPauseBtn.textContent=running?'إيقاف':'تشغيل'};
stepBackBtn.onclick=()=>{year=Math.max(0,year-10);updateUI()};
stepFwdBtn.onclick=()=>{year=Math.min(1000,year+10);updateUI()};
speedSlider.oninput=()=>{speed=parseInt(speedSlider.value);updateUI()};
scrub.oninput=()=>{year=parseInt(scrub.value);updateUI()};
scenarioSelect.onchange=()=>{scenario=scenarioSelect.value};

// لغة (مبدئياً فقط للتجريب)
langToggleBtn.onclick=()=>{
  if(langToggleBtn.textContent==='EN'){langToggleBtn.textContent='AR'} else {langToggleBtn.textContent='EN'};
};

renderEvents();
updateUI();
tick();